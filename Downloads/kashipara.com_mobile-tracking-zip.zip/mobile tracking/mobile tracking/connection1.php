<?php
$con=mysql_connect("localhost","root","")or die("cannot connect");
mysql_select_db("javapjt",$con)or die ("cannot connect to database");
?>
