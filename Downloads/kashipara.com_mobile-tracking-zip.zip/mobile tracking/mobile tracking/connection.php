<?php
$con=mysql_connect("localhost","srishtip_syam","syam1234")or die("cannot connect");
mysql_select_db("srishtip_towerdb",$con)or die ("cannot connect to database");
?>
